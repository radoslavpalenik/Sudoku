---- ITU 2019/20 ----

-- Authors: Radoslav Páleník <xpalen05@stud.fit.vutbr.cz>, Daniel Pohančaník <xpohan03@stud.fit.vutbr.cz>, Michal Řezáč <xrezac20@stud.fit.vutbr.cz>

Spustenie aplikácie

Pre spustenie je potrebné mať nainštalovaný Python ver. 3.7+, v ktorej by mal byť aj balík tkinter 

Linux:
V termináli príkazom "python3 sudoku.py" 

Windows:
V terminal príkazom "python sudoku.py"
